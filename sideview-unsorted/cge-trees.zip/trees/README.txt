Simple animated trees in Spine JSON format.

You can open it e.g. in Castle Game Engine ( https://castle-engine.io/ ) that supports Spine. You can quickly test it by opening in our model viewer, view3dscene: https://castle-engine.io/view3dscene.php .

By Paweł Wojciechowicz from https://cat-astrophe-games.com/ .
Licensed on the GNU GPL >= 2 terms.
