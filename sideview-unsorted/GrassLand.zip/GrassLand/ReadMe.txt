---------------------------------------
Multi Platformer Tileset
Free version

Made and distributed by Shackhal
https://shackhal.itch.io/

---------------------------------------

Thank you for downloading this tileset. This is an old version of the Grassland environment, as it was revamped. If you like it, consider to buy the paid version.

Currently the paid version have 4 tilesets. And those who already bought it have access to future updates.

The license is CC0 (Creative Commons Zero), so the content is free to use in any personal, educational and commercial projects.
Giving credits (Diego del Solar or "Shackhal") is not mandatory, but greatly appreciated.

---------------------------------------

You can give feedback here:
https://shackhal.itch.io/multi-platformer-tileset/community

Follow me for updates:

Twitter: @shackhal
Blog: http://shackhal.tumblr.com/



