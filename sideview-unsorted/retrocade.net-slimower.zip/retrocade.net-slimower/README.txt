## Meta info:

	Credit: Retrocade.net
	Source game: Slimower
	Licensed under: Creative Commons Attribution 4.0 International (https://creativecommons.org/licenses/by/4.0/)
	
	Play the game: http://retrocade.net/game/slimower/
	Source code: https://github.com/RetrocadeNet/slimower
	Support Retrocade.net: http://retrocade.net/how-to-support-retrocade-net/

	More opensource games and artwork on: 
	http://retrocade.net/open-art/